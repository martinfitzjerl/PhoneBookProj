package com.Sam.phoneBookProjOne;

import java.util.Scanner;


public class Person {
	
	String firstName;
	String lastName;
	String phoneNumber;
	String city;
	String state;
	String zipCode;
	




	public Person() {
		super();
//		this.firstName = firstName;
//		this.lastName = lastName;
		
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firsName) {
		this.firstName = firsName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	public String personString() {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		
		return firstName + ", " + lastName + ", " + phoneNumber + ", " + city + ", " + state + ", " + zipCode + ", ";
	}




	

}



//public String addPerson()
//{
//Scanner personScanner = new Scanner(System.in);
//	String personString="";
//	
//	System.out.println("Please enter your first Name");
//	firstName= personScanner.nextLine();
//	System.out.println("Please enter your last name");
//	lastName=personScanner.nextLine();
//	
//	
//	personString=firstName+", "+lastName;
//	
//	personScanner.close();
//	return personString;
//}
