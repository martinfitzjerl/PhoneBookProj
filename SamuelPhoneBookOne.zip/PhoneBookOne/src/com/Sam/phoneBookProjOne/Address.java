package com.Sam.phoneBookProjOne;

import java.io.Console;

import java.util.Scanner;

public class Address {
	
	String streetNumber;
	String street;
	String state;
	String city;
	String zip;
	
	
	public Address() {
		super();
		this.streetNumber = streetNumber;
		this.street = street;
		this.state = state;
		this.city = city;
		this.zip = zip;
	}
	
	
	
	public String getStreetNumber() {
		return streetNumber;
	}
	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}


	public String  setAddress()
	
	{
		Scanner addressScanner = new Scanner(System.in);
		String addressString="";
		
		System.out.println("Please enter your street number");
		streetNumber= addressScanner.nextLine();
		System.out.println("Please enter your street name");
		street=addressScanner.nextLine();
		System.out.println("Please enter your City");
		city=addressScanner.nextLine();
		System.out.println("Please enter your State");
		state=addressScanner.nextLine();
		System.out.println("Please enter your Zip Code");
		zip=addressScanner.nextLine();
		
		addressString=String.valueOf(streetNumber)+", "+street+", "+state+", "+city+", "+ String.valueOf(zip);
		
		addressScanner.close();
		return addressString;
	}
	
}
