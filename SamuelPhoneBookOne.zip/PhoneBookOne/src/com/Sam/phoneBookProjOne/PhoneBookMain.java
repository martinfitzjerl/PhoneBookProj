package com.Sam.phoneBookProjOne;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class PhoneBookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		String phoneBook[][];
		
		
		
		Person personOne = new Person();
		
		String personArray[] = new String[0];
		

		
		Events events = new Events();


		// Welcome message
		System.out.println("Welcome!\n \nPlease follow the directions, below to Search, Update, Delete, or Add Records.");

		System.out.println("\n");

		// Menu
		System.out.println("Enter 1 to create a new entry");
		System.out.println("Enter 2 to search for an existing entry by first name");
		System.out.println("Enter 3 to search for an existing entry by last name");
		System.out.println("Enter 4 to search for an existing entry by full name");
		System.out.println("Enter 5 to search for an existing entry by telephone number");
		System.out.println("Enter 6 to search for an existing entry by city");
		System.out.println("Enter 7 to search for an existing entry by state");
		System.out.println("Enter 8 to search for an existing entry by address");
		System.out.println("Enter 9 to delete an existing entry by telephone number");
		System.out.println("Enter 10 to update an existing entry by telephone number");
		System.out.println("Enter 11 to sort entries in ascending order");
		System.out.println("Enter 12 to exit program");
		System.out.println("Enter 13 to use Events feature");

		System.out.println("\n");

		Scanner scanner = new Scanner(System.in);







		String inputString;

		String choice = "0";

		while (choice != "12") {
			
			
			choice = scanner.nextLine();


			switch (choice) {
			
			case "0": {
				
				System.out.println("-----MENU-----");
				System.out.println("\n");

				// Menu
				System.out.println("Enter 0 to show menu");
				System.out.println("Enter 1 to create a new entry");
				System.out.println("Enter 2 to search for an existing entry by first name");
				System.out.println("Enter 3 to search for an existing entry by last name");
				System.out.println("Enter 4 to search for an existing entry by full name");
				System.out.println("Enter 5 to search for an existing entry by telephone number");
				System.out.println("Enter 6 to search for an existing entry by city");
				System.out.println("Enter 7 to search for an existing entry by state");
				System.out.println("Enter 8 to search for an existing entry by address");
				System.out.println("Enter 9 to delete an existing entry by telephone number");
				System.out.println("Enter 10 to update an existing entry by telephone number");
				System.out.println("Enter 11 to sort entries in ascending order");
				System.out.println("Enter 12 to exit program");
				System.out.println("Enter 13 to use Events feature");
				System.out.println("Enter 14 to show menu");
				
				break;

			}
			

			case "1":

			{

				System.out.println("Add new entry");
				System.out.println("Enter the full details of the person; Ex: John Doe, 114 Market St, St Louis, MO, 63403, 6366435698");
				String newEntry = scanner.nextLine();
				String newEntry1 = scanner.nextLine();
				String newEntry2 = scanner.nextLine();
				String newEntry3 = scanner.nextLine();
				String newEntry4 = scanner.nextLine();
				String newEntry5 = scanner.nextLine();
				
				
				personOne.setFirstName(newEntry);
				personOne.setLastName(newEntry1);
				personOne.setPhoneNumber(newEntry2);
				personOne.setCity(newEntry3);
				personOne.setState(newEntry4);
				personOne.setZipCode(newEntry5);



				
				int arraySize = personArray.length + 1;
				String[] swapArray = new String[arraySize];
				
				for(int i = 0; i < personArray.length; i++) {
					swapArray[i] = personArray[i];
				}
				
				swapArray[arraySize - 1] = personOne.personString();
				personArray = swapArray;
				
				
				for(int i = 0; i < swapArray.length; i++) {
					
					System.out.println("---  ---  ---");
					System.out.println("    Entry    ");
					System.out.println("---  ---  ---");
					
					System.out.println(personArray[i]);
				}
				
				
	

				break;
			}

			case "2": {

				System.out.println("Search by the first name of the person; Ex: Mark ");
				String firstName = scanner.nextLine();
				

				

				if(personArray.length == 0) {
					System.out.println("empty phonebook");
					

					
					

					

				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(firstName)) {
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println("not found at "  + "column" + i);
						
					}
					

				}
				
				

				
				


				break;
				
			}

			case "3": {
				
				
				

				System.out.println("Search by the Last name of the person; Ex: Haffer ");
				String lastName = scanner.nextLine();
				
				

				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(lastName)) {
						System.out.println(personArray[i] + " Was found at "  + "column" + i);
					}
					else {
						System.out.println("not found at "  + "column" + i);
					}
					

				}
				





				break;
			}

			case "4": {
				
				String fullName = scanner.nextLine();

				System.out.println("Enter the Full name of the person to search; Ex: Jack Hassly ");

				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(fullName)) {
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println("not found at "  + "column" + i);
					}
					

				}



				break;
			}

			case "5": {
				
				System.out.println("Enter the phone number of the person; Ex: 867 530 0900 ");
				String phoneNumber = scanner.nextLine();

				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(phoneNumber)) {
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println("not found at " + "column" + i);
					}
					

				}

				

				
				

				
				break;
			}

			case "6": {

				System.out.println("Enter the city of the person; Ex: Boston ");
				String city = scanner.nextLine();


				
				

				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(city)) {
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println("not found at " + "column" + i);
					}
					

				}
				

				break;
			}

			case "7": {

				System.out.println("Enter the state of the person; Ex: Colorado ");
				String state = scanner.nextLine();


				

				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(state)) {
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println("not found at " + "column" + i);
					}
					
					//
				}
				
				break;
			}

			case "8": {

				System.out.println("Enter the street of the person; Ex: 123 Street");
				String street = scanner.nextLine();


				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(street)) {
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println("not found at " + "column" + i);
					}
					
					//
				}

				break;
			}

			case "9": {

				System.out.println("Delete by telephone number; Ex: 123-212-1342");
				String telephoneNumber = scanner.nextLine();

				
				if(personArray.length == 0) {
					System.out.println("empty phonebook");
				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(telephoneNumber)) {
						
						String[] emptyArray = {null};
						personArray = emptyArray;

						
						System.out.println("Entry of " +  telephoneNumber + " was successfully deleted. ");
					}
					else {
						System.out.println("not found at " + "column" + i);
						System.out.println(personArray[i] + " Was found at " + "column" + i);
						System.out.println("Entry of " + personArray[i]  +  telephoneNumber + " was successfully deleted. ");
					}
					

				}
				


				break;
			}

			case "10": {

				System.out.println("Update by telephone number; Ex: 123-212-1342");
				String telephoneNumber = scanner.nextLine();

				System.out.println(telephoneNumber + "case 10");
				
				if(personArray.length == 0) {
					System.out.println("Empty phone book entries");

				}
				
				
				for (int i = 0; i < personArray.length; i++) {
					if(personArray[i].contains(telephoneNumber)) {
						
						String[] emptyArray = {null};
						personArray[i] = scanner.nextLine();
	
						
						
						System.out.println("Entry was updated with " + telephoneNumber);

						
						
						System.out.println(personArray[i] + " Was found at " + "column" + i);
					}
					else {
						System.out.println(telephoneNumber + "not found at " + "column" + i);
					}
					
					//
				}
				


				break;
			}

			case "11": {

				System.out.println("Show all records in ascending order");
				if(personArray.length != 0) {
					for(int i = 0; i < personArray.length; i++) {
				
						System.out.println(personArray[i]);
						Arrays.sort(personArray);
						System.out.println(personArray);
					}
				}
				//scanner.close();
				break;
				
				

			}

			case "13": {
				
				System.out.println("-*-   ---    -*-");
				System.out.println(" '   Events   ' ");
				System.out.println(" |-   ---    -| ");

				System.out.println("Enter the full details of the event; Ex: Lee's Anniversary, 114 Market St, St Louis, MO, 63403, 6366435698");
				String newEntry = scanner.nextLine();
				String newEntry1 = scanner.nextLine();
				String newEntry2 = scanner.nextLine();
				String newEntry3 = scanner.nextLine();
				String newEntry4 = scanner.nextLine();
				String newEntry5 = scanner.nextLine();
				
				
				events.seteFName(newEntry);
				events.seteLName(newEntry1);
				events.setePNumber(newEntry2);
				events.seteCity(newEntry3);
				events.seteState(newEntry4);
				events.seteZipCode(newEntry5);



				
				int arraySize = personArray.length + 1;
				String[] swapArray = new String[arraySize];
				
				for(int i = 0; i < personArray.length; i++) {
					swapArray[i] = personArray[i];
				}
				
				swapArray[arraySize - 1] = events.eString();
				personArray = swapArray;
				
				
				for(int i = 0; i < swapArray.length; i++) {
					
					System.out.println("-*-      ---     -*-");
					System.out.println(" '   Events List  ' ");
					System.out.println(" |-      ---     -| ");
					
					System.out.println(personArray[i]);
				}

				break;
			}

			case "12": {
				
				System.out.println("Exitting Program");
	



				break;
			}
			

			


			default: {

				System.out.println("You have entered an invalid entry return to main menu for valid example entry");
				break;

			} // switch
			
			
			}//

		} // while

	}// Main

}// PhoneBookMain


