package com.Sam.phoneBookProjOne;

import java.util.Scanner;


public class Events {
	
	String eFName;
	String eLName;
	String ePNumber;
	String eCity;
	String eState;
	String eZipCode;
	




	public Events() {
		super();
//		this.firstName = firstName;
//		this.lastName = lastName;
		
	}
	public String getCity() {
		return eCity;
	}
	public void seteCity(String eCity) {
		this.eCity = eCity;
	}
	public String geteState() {
		return eState;
	}
	public void seteState(String eState) {
		this.eState = eState;
	}
	public String geteZipCode() {
		return eZipCode;
	}
	public void seteZipCode(String eZipCode) {
		this.eZipCode = eZipCode;
	}
	public String geteFName() {
		return eFName;
	}
	public void seteFName(String eFName) {
		this.eFName = eFName;
	}
	public String geteLName() {
		return eLName;
	}
	public void seteLName(String eLName) {
		this.eLName = eLName;
	}

	
	public String getePNumber() {
		return ePNumber;
	}
	public void setePNumber(String ePNumber) {
		this.ePNumber = ePNumber;
	}
	
	
	public String eString() {
		
		this.eFName = eFName;
		this.eLName = eLName;
		this.ePNumber = ePNumber;
		this.eCity = eCity;
		this.eState = eState;
		this.eZipCode = eZipCode;
		
		return eFName + ", " + eLName + ", " + ePNumber + ", " + eCity + ", " + eState + ", " + eZipCode + ", ";
	}




	

}



//public String addPerson()
//{
//Scanner personScanner = new Scanner(System.in);
//	String personString="";
//	
//	System.out.println("Please enter your first Name");
//	firstName= personScanner.nextLine();
//	System.out.println("Please enter your last name");
//	lastName=personScanner.nextLine();
//	
//	
//	personString=firstName+", "+lastName;
//	
//	personScanner.close();
//	return personString;
//}
